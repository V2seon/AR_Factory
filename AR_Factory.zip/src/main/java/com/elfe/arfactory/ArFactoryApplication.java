package com.elfe.arfactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArFactoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArFactoryApplication.class, args);
	}

}
